<?php
// Shim to include enhanced class if available in updated distribution
// This file is added from updated package.
if (!defined('ABSPATH')) { exit; }

// Placeholder for any billing dashboard hooks (UI integration deferred)
