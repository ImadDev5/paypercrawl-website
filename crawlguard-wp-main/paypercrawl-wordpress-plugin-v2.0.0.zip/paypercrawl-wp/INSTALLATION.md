# PayPerCrawl WordPress Plugin v2.0.0 Installation Guide

## 🚀 Quick Installation

1. **Upload Plugin**
   - Go to WordPress Admin → Plugins → Add New → Upload Plugin
   - Choose the paypercrawl-wp.zip file
   - Click "Install Now"

2. **Activate Plugin**
   - Click "Activate Plugin" after installation
   - The plugin will automatically connect to the production database

3. **Configure Settings**
   - Go to WordPress Admin → PayPerCrawl
   - Your site will be automatically registered
   - Configure monetization settings as needed

## 🔑 Database Connection

The plugin is pre-configured with production database credentials:
- **Host**: ep-steep-resonance-adkp2zt6-pooler.c-2.us-east-1.aws.neon.tech
- **Database**: neondb
- **Connection**: Automatic (no manual setup required)

## ✅ Features Included

- ✅ **Bot Detection**: 95%+ accuracy AI bot detection
- ✅ **Monetization**: Turn bot traffic into revenue
- ✅ **Analytics**: Real-time traffic and revenue analytics
- ✅ **API Integration**: Full API authentication system
- ✅ **Payment Processing**: Stripe integration ready
- ✅ **Admin Dashboard**: Complete management interface
- ✅ **Configuration**: Flexible settings management

## 🛠️ Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- PDO PostgreSQL extension (for database connectivity)
- SSL certificate (recommended for production)

## 🔧 Troubleshooting

If you encounter any issues:
1. Check that PDO PostgreSQL extension is installed
2. Verify your hosting supports outbound HTTPS connections
3. Contact support at support@paypercrawl.tech

## 📞 Support

- Website: https://paypercrawl.tech
- Email: support@paypercrawl.tech
- Documentation: https://docs.paypercrawl.tech

---
**PayPerCrawl Team** - Turning AI bot traffic into revenue since 2024
